////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package apps.suncorp_bank.components.composite.interest_rates;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.adobe.cq.sightly.WCMUsePojo;
import au.com.suncorp.foundation.core.utils.CRXUtil;
import au.com.suncorp.foundation.services.SuncorpConfigurationService;
import org.apache.commons.lang3.StringUtils;

/**
 * Fetches the API URL Path.
 */
public class InterestRates extends WCMUsePojo
{ 

    // LOGGER
    private static final Logger LOGGER = LoggerFactory.getLogger(InterestRates.class);

    private String apiURLPath;
    private String apiProductCodeURLPath;
    private String uniquePath;

    /**
     * This method populates the API url path from OSGI.
     *
     * @return void
     */
    @Override
    public void activate() throws Exception
    {
        LOGGER.info("Entering InterestRates : activate() method");
        apiURLPath = StringUtils.EMPTY;
        apiProductCodeURLPath = StringUtils.EMPTY;
        uniquePath = StringUtils.EMPTY;
        uniquePath = (getResource().getPath().split("jcr:content/")[1]).replace("/", "-");
        SuncorpConfigurationService configService = CRXUtil.getServiceReference(
                SuncorpConfigurationService.class, getRequest());

        if (null != configService) {
            apiURLPath = configService.getStringConfigValue("interestrates.api");
            apiProductCodeURLPath = configService.getStringConfigValue("interestratesproductcode.api");
        }

        LOGGER.info("Entering InterestRates : activate() method : API URL" + apiURLPath);
        LOGGER.info("Entering InterestRates : activate() method : API Product Code URL" + apiProductCodeURLPath);
        LOGGER.info("Exiting InterestRates : activate() method");
    }

    /**
     * Get API URL Path.
     *
     * @return String
     */
    public String getApiURLPath()
    {
        return apiURLPath;
    }

    /**
     * Get API Product Code URL Path.
     *
     * @return String
     */
    public String getApiProductCodeURLPath()
    {
        return apiProductCodeURLPath;
    }

    /**
     * Minimal Content Path for This component.
     *
     * @return String
     */
    public String getUniquePath()
    {
        return uniquePath;
    }

}
